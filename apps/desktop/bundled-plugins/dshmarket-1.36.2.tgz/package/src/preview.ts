import type { ActivationInfo, InstalledRepoHints, InstalledRepoIdentities } from './client/market-data.ts'
import { matchInstalledName } from './client/market-data.ts'
import type { Registry, RegistryPlugin } from './registry.ts'

export const MARKET_PREVIEW_SCHEMA = 'dsh-market/preview/v1' as const

export type MarketPreviewState = 'installed' | 'uninstalled' | 'restart' | 'unavailable'

export interface MarketPreviewItem {
  name: string
  owner: string
  category: string[]
  categoryLabels: Record<string, Record<string, string>>
  description: Record<string, string>
  downloads: number | null
  stars: number | null
  packageName: string
  state: MarketPreviewState
}

export interface MarketPreviewSnapshot {
  schema: typeof MARKET_PREVIEW_SCHEMA
  updated: string
  items: MarketPreviewItem[]
}

interface PreviewInstalledState {
  installed: Record<string, string>
  repoIdentities?: InstalledRepoIdentities
  repoHints?: InstalledRepoHints
  activation?: Record<string, ActivationInfo>
}

function normalized(plugin: RegistryPlugin): import('./client/market-data.ts').RegistryPlugin {
  const { npm, stars, ...rest } = plugin
  return { ...rest, ...(npm == null ? {} : { npm }), ...(stars == null ? {} : { stars }) }
}

function stateFor(name: string | null, activation: Record<string, ActivationInfo>): MarketPreviewState {
  if (name === null) return 'uninstalled'
  const state = activation[name]?.state
  if (state === 'restart') return 'restart'
  if (state === 'broken' || state === 'missing' || state === 'disabled' || state === 'inert') return 'unavailable'
  return 'installed'
}

/** Build the four-card home preview from the same matching evidence as the full market. */
export function buildMarketPreview(registry: Registry, local: PreviewInstalledState): MarketPreviewSnapshot {
  const plugins = registry.plugins.map(normalized)
  const candidates = registry.plugins
    .filter(plugin => plugin.name !== 'dsh-market' && plugin.npm !== 'dshmarket')
    .filter(plugin => plugin.deprecated !== true && plugin.install.trim() !== '')
    .sort((a, b) => {
      const downloads = (b.downloads ?? -1) - (a.downloads ?? -1)
      if (downloads !== 0) return downloads
      const stars = (b.stars ?? -1) - (a.stars ?? -1)
      return stars !== 0 ? stars : a.name.localeCompare(b.name)
    })
    .slice(0, 4)

  return {
    schema: MARKET_PREVIEW_SCHEMA,
    updated: registry.updated,
    items: candidates.map(plugin => {
      const packageName = matchInstalledName(
        normalized(plugin), local.installed, local.repoIdentities, plugins, local.repoHints,
      )
      const categories = Array.isArray(plugin.category) ? plugin.category : [plugin.category]
      return {
        name: plugin.name,
        owner: plugin.owner,
        category: categories,
        categoryLabels: Object.fromEntries(categories.map(id => [id, registry.categories[id] ?? {}])),
        description: plugin.description,
        downloads: plugin.downloads ?? null,
        stars: plugin.stars ?? null,
        packageName: packageName ?? plugin.npm ?? plugin.name,
        state: stateFor(packageName, local.activation ?? {}),
      }
    }),
  }
}
