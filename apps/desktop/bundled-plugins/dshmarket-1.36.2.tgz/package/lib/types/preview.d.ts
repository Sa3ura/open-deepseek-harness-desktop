import type { ActivationInfo, InstalledRepoHints, InstalledRepoIdentities } from './client/market-data.ts';
import type { Registry } from './registry.ts';
export declare const MARKET_PREVIEW_SCHEMA: 'dsh-market/preview/v1';
export type MarketPreviewState = 'installed' | 'uninstalled' | 'restart' | 'unavailable';
export interface MarketPreviewItem {
    name: string;
    owner: string;
    category: string[];
    categoryLabels: Record<string, Record<string, string>>;
    description: Record<string, string>;
    downloads: number | null;
    stars: number | null;
    packageName: string;
    state: MarketPreviewState;
}
export interface MarketPreviewSnapshot {
    schema: typeof MARKET_PREVIEW_SCHEMA;
    updated: string;
    items: MarketPreviewItem[];
}
interface PreviewInstalledState {
    installed: Record<string, string>;
    repoIdentities?: InstalledRepoIdentities;
    repoHints?: InstalledRepoHints;
    activation?: Record<string, ActivationInfo>;
}
/** Build the four-card home preview from the same matching evidence as the full market. */
export declare function buildMarketPreview(registry: Registry, local: PreviewInstalledState): MarketPreviewSnapshot;
export {};
